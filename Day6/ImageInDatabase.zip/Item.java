/**
 * 
 * I declare that this code was written by me, ymlee. 
 * I will not copy or allow others to copy my code. 
 * I understand that copying code is considered as plagiarism.
 * 
 * Student Name: Desmond Lee
 * Student ID: 7777777
 * Class: DEW
 * Date created: 2022-Sep-14 4:06:40 pm 
 * 
 */

package com.sbstransit.booklinkSBS;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;

/**
 * @author ymlee
 *
 */
@Entity
public class Item {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int Id;
	
	@NotNull
	@NotEmpty(message="Name cannot be empty")
	@Size(min=5,max=50,message="Name must be between 5 and 50 characters!")
	private String name;
	
	@NotNull
	@NotEmpty(message="Description cannot be empty")
	@Size(min=5,max=100,message="Name must be between 5 and 50 characters!")
	private String description;
	
	@NotNull(message="Item price cannot be empty!")
    @DecimalMin(value="0.1", message="Item price should be a positive value!")
    private Double price;
    
    @NotNull(message="Item quantity cannot be empty!")
    @Min(value=1, message="Item price should be a positive value!")
    private Integer quantity;
    
    private String imgName;
    
    @Lob
    private byte[] imgData;
    
	@ManyToOne
	@JoinColumn(name="category_id", nullable=false)
	@NotNull(message="Category must be selected!")
	private Category category;
	
	/**
	 * @return the category
	 */
	public Category getCategory() {
		return category;
	}
	/**
	 * @param category the category to set
	 */
	public void setCategory(Category category) {
		this.category = category;
	}
	/**
	 * @return the id
	 */
	public int getId() {
		return Id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		Id = id;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the price
	 */
	public Double getPrice() {
		return price;
	}
	/**
	 * @param price the price to set
	 */
	public void setPrice(Double price) {
		this.price = price;
	}
	/**
	 * @return the quantity
	 */
	public Integer getQuantity() {
		return quantity;
	}
	/**
	 * @param quantity the quantity to set
	 */
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	/**
	 * @return the imgName
	 */
	public String getImgName() {
		return imgName;
	}
	/**
	 * @param imgName the imgName to set
	 */
	public void setImgName(String imgName) {
		this.imgName = imgName;
	}
	/**
	 * @return the imgData
	 */
	public byte[] getImgData() {
		return imgData;
	}
	/**
	 * @param imgData the imgData to set
	 */
	public void setImgData(byte[] imgData) {
		this.imgData = imgData;
	}
	
	
}
