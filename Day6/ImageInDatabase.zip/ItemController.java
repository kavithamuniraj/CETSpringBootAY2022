/**
 * 
 * I declare that this code was written by me, ymlee. 
 * I will not copy or allow others to copy my code. 
 * I understand that copying code is considered as plagiarism.
 * 
 * Student Name: Desmond Lee
 * Student ID: 7777777
 * Class: DEW
 * Date created: 2022-Sep-14 4:12:22 pm 
 * 
 */

package com.sbstransit.booklinkSBS;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

/**
 * @author ymlee
 *
 */
@Controller
public class ItemController {

	@Autowired
	private ItemRepository itemRepository;
	
	@Autowired
	private CategoryRepository categoryRepository;
	
	@Autowired
	private ItemVRepository itemVRepository;
	
	@GetMapping("/xyz")
	public String viewItems(Model model) {
		List<Item> items = itemRepository.findAll();
		model.addAttribute("itemList", items);
		
		List<ItemV> itemvs = itemVRepository.findAll();
		return "abc";
	}
	
	@GetMapping("/items/add")
	public String addItem(Model model) {
		model.addAttribute("item", new Item());
		
		List<Category> catList = categoryRepository.findAll();
		model.addAttribute("catList",catList);
		
		return "add_item";
	}
	
	@PostMapping("items/save")
	public String saveItem(@Valid Item item, BindingResult bindingResult, 
			@RequestParam("itemImage") MultipartFile imgFile, Model model) {
		if (bindingResult.hasErrors()) {
			List<Category> catList = categoryRepository.findAll();
			model.addAttribute("catList",catList);
			
            System.out.println(bindingResult.getErrorCount());
            System.out.println(bindingResult.toString());
			return "add_item";
		}
		String imgName = imgFile.getOriginalFilename();
		
		item.setImgName(imgName);
		try {
			item.setImgData(imgFile.getBytes());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		itemRepository.save(item);
		
		return "redirect:/xyz";
	}
	
	@PostMapping("items/saveold")
	public String saveItemOld(@Valid Item item, BindingResult bindingResult, 
			@RequestParam("itemImage") MultipartFile imgFile, Model model) {
		if (bindingResult.hasErrors()) {
			List<Category> catList = categoryRepository.findAll();
			model.addAttribute("catList",catList);
			
            System.out.println(bindingResult.getErrorCount());
            System.out.println(bindingResult.toString());
			return "add_item";
		}
		String imgName = imgFile.getOriginalFilename();
		
		item.setImgName(imgName);
		
//		Item savedItem = itemRepository.save(item);
//		
//		try {
//			String uploadDir = "uploads/items/" + savedItem.getId();
//			Path uploadPath = Paths.get(uploadDir);
//			System.out.println("Directory path: " + uploadPath);
//			
//			if (!Files.exists(uploadPath)) {
//				Files.createDirectories(uploadPath);
//			}
//			
//			Path fileToCreatePath = uploadPath.resolve(imgName);
//			System.out.println("File path: " + fileToCreatePath);
//			
//			Files.copy(imgFile.getInputStream(), fileToCreatePath, StandardCopyOption.REPLACE_EXISTING);
//		}catch(IOException io) {
//			io.printStackTrace();
//		}
		return "redirect:/xyz";
	}
	
	@GetMapping("items/search")
	@Transactional
	public String searchItems(Model model, String searchStr) {
		List<Item> items = itemRepository.searchItems(searchStr);
		model.addAttribute("itemList", items);
		return "abc";
	}
	
	@GetMapping("items/{id}")
	public String viewSingleItem(@PathVariable("id") Integer id, Model model) {
		Item item = itemRepository.getReferenceById(id);
		model.addAttribute("item", item);
		return "view_single_item";
	}
	
	@GetMapping("/items/edit/{id}")
	public String editItem(@PathVariable("id") Integer id, Model model) {
		Item item = itemRepository.getReferenceById(id);
		model.addAttribute("item", item);
		
		List<Category> catList = categoryRepository.findAll();
		model.addAttribute("catList",catList);
		return "edit_item";
	}
	
	@PostMapping("/items/edit/{id}")
	public String saveUpdatedItem(@PathVariable("id") Integer id, @Valid Item item, BindingResult bindingResult, @RequestParam("itemImage") MultipartFile imgFile, Model model) {
		//itemRepository.save(item);
		this.saveItem(item, bindingResult, imgFile,model);
		return "redirect:/xyz";
	}
	
	@GetMapping("/items/delete/{id}")
	public String deleteItem(@PathVariable("id") Integer id) {
		itemRepository.deleteById(id);
		return "redirect:/xyz";
	}
	
	@GetMapping(path = "/items/image/{id}")
	public ResponseEntity<Resource> getImgData(@PathVariable("id") Integer id) throws IOException {
		Item item = itemRepository.getReferenceById(id);
	    ByteArrayResource resource = new ByteArrayResource(item.getImgData());

	    return ResponseEntity.ok()
	            .contentLength(item.getImgData().length)
	            .contentType(MediaType.APPLICATION_OCTET_STREAM)
	            .body(resource);
	}
}
